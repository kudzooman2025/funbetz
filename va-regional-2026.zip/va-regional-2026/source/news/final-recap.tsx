"use client";

import Link from "next/link";

export default function FinalRecapPage() {
  return (
    <div className="max-w-2xl mx-auto px-4 py-8 pb-24">
      <Link href="/schedule" className="inline-flex items-center gap-1.5 text-brand-muted hover:text-white text-sm mb-6 transition-colors">
        Back to Schedule
      </Link>

      <article className="space-y-6">
        <div className="space-y-2">
          <div className="inline-flex items-center gap-2 bg-brand-yellow/10 border border-brand-yellow/30 rounded-full px-3 py-1">
            <span className="text-brand-yellow text-xs font-bold uppercase tracking-widest">Champions</span>
          </div>
          <h1 className="text-2xl font-bold text-white leading-tight">
            FC DELCO Are Champions: A 1-0 Final for the Ages
          </h1>
          <p className="text-brand-muted text-sm">
            May 4, 2026 - VA Regional - U13 AD - MLS NEXT Cup Qualifiers
          </p>
        </div>

        <div className="border-t border-brand-border" />

        <div className="bg-brand-surface border border-brand-border rounded-xl p-5">
          <p className="text-brand-muted text-xs uppercase tracking-widest font-bold mb-4 text-center">Final Score</p>
          <div className="flex items-center justify-between gap-4">
            <div className="flex-1 text-center">
              <p className="text-white font-bold text-lg">FC DELCO</p>
              <p className="text-brand-muted text-xs mt-0.5">MLSNEXT</p>
            </div>
            <div className="text-center px-4">
              <p className="text-white font-black text-4xl tracking-tight">1 - 0</p>
              <p className="text-brand-muted text-xs mt-1">CHAMPIONS</p>
            </div>
            <div className="flex-1 text-center">
              <p className="text-white font-bold text-lg">Coppermine SC</p>
              <p className="text-brand-muted text-xs mt-0.5">MLSNEXT</p>
            </div>
          </div>
        </div>

        <p className="text-white/90 text-base leading-relaxed">
          It came down to 50 minutes of tension, a missed penalty, a late goal, and a final whistle that
          sent FC DELCO into delirium. The machine that had run through this entire tournament without
          losing a single game has its trophy. Six games. No losses. One champion.
        </p>

        <p className="text-white/90 text-base leading-relaxed">
          When it was all said and done, FC DELCO beat Coppermine SC 1-0 in a championship final that
          was decided in the dying minutes -- and kept on edge by a moment in the first half that could
          have changed everything.
        </p>

        <div className="border-t border-brand-border" />

        <div className="space-y-3">
          <h2 className="text-white font-bold text-lg">A Penalty That Was Not</h2>
          <p className="text-white/90 text-base leading-relaxed">
            Coppermine had spent the entire tournament grinding. They knocked out a Charlotte Independence
            side that had not conceded in four games. They had shown they could find another gear when
            the moment demanded it. And in the first half of the final, that moment arrived.
          </p>
          <p className="text-white/90 text-base leading-relaxed">
            A penalty was awarded to Coppermine. The crowd held its breath. The DELCO keeper set his feet.
            The shot went up -- and over. High over the crossbar. A miss that will live in the memory of
            everyone who was there.
          </p>
        </div>

        <div className="bg-red-500/10 border border-red-500/30 rounded-xl p-5 space-y-2">
          <p className="text-red-400 font-bold text-sm uppercase tracking-widest">The Penalty</p>
          <p className="text-white font-semibold text-base">
            First half - Coppermine awarded penalty - Shot sails over the crossbar
          </p>
          <p className="text-white/70 text-sm leading-relaxed">
            The biggest moment of the first half came and went without a goal. What might have been
            a 1-0 lead and a completely different final became a 0-0 scoreline -- and a second half
            where both teams knew anything could happen.
          </p>
        </div>

        <div className="space-y-3">
          <h2 className="text-white font-bold text-lg">Twenty-Five Minutes of Nerve</h2>
          <p className="text-white/90 text-base leading-relaxed">
            The second half was exactly what you would expect from two teams who refused to lose at
            this tournament. Coppermine pushed. DELCO defended. Chances came and went at both ends.
            The kind of game where the longer it stays level, the more it feels like neither team
            will ever score.
          </p>
          <p className="text-white/90 text-base leading-relaxed">
            And then, with fewer than five minutes remaining in the second half, DELCO found it.
          </p>
        </div>

        <div className="bg-green-500/10 border border-green-500/30 rounded-xl p-5 space-y-2">
          <p className="text-green-400 font-bold text-sm uppercase tracking-widest">The Winning Goal</p>
          <p className="text-white font-semibold text-base">
            Final minutes - FC DELCO - 1-0
          </p>
          <p className="text-white/70 text-sm leading-relaxed">
            Late. Decisive. Pure DELCO. When the moments mattered most all tournament long, this group
            found a way. They found it one final time.
          </p>
        </div>

        <p className="text-white/90 text-base leading-relaxed">
          Coppermine threw everything at the final minutes but DELCO held firm, just as they had held
          firm through every moment of adversity all weekend. The whistle blew. Six games. Six results
          in their favor. Zero losses.
        </p>

        <div className="border-t border-brand-border" />

        <div className="space-y-3">
          <h2 className="text-white font-bold text-lg">The Perfect Run</h2>
          <p className="text-white/90 text-base leading-relaxed">
            Look back at what FC DELCO did over the course of this tournament and it is almost hard
            to believe. Three group stage wins, including a dramatic late goal to beat FA 2-1 in their
            final group game. A 2-0 quarterfinal win over Queen City. A penalty shootout victory over
            Alexandria -- surviving a controversy, surviving extra time, surviving everything -- and now
            a 1-0 championship win over the team that had been the tournament's other outstanding side.
          </p>
        </div>

        <div className="bg-brand-surface border border-brand-border rounded-xl p-5">
          <p className="text-brand-muted text-xs uppercase tracking-widest font-bold mb-4">FC DELCO - Tournament Record</p>
          <div className="grid grid-cols-3 gap-3">
            <div className="text-center">
              <p className="text-white font-black text-3xl">6</p>
              <p className="text-brand-muted text-xs mt-1">Games Played</p>
            </div>
            <div className="text-center">
              <p className="text-brand-yellow font-black text-3xl">6</p>
              <p className="text-brand-muted text-xs mt-1">Wins</p>
            </div>
            <div className="text-center">
              <p className="text-white font-black text-3xl">0</p>
              <p className="text-brand-muted text-xs mt-1">Losses</p>
            </div>
          </div>
          <div className="mt-4 pt-4 border-t border-brand-border grid grid-cols-2 gap-3">
            <div className="text-center">
              <p className="text-white font-black text-2xl">1</p>
              <p className="text-brand-muted text-xs mt-1">PK shootout survived</p>
            </div>
            <div className="text-center">
              <p className="text-white font-black text-2xl">1</p>
              <p className="text-brand-muted text-xs mt-1">Disallowed goal endured</p>
            </div>
          </div>
        </div>

        <div className="border-t border-brand-border" />

        <div className="space-y-3">
          <h2 className="text-white font-bold text-lg">A Tale of Two Moments</h2>
          <p className="text-white/90 text-base leading-relaxed">
            If you are a Coppermine supporter, you will replay that penalty all week. A converted spot
            kick could have changed the entire complexion of the game. It would have been 1-0 Coppermine.
            DELCO -- a team that had already shown they could come back from the edge -- would have needed
            to find an answer.
          </p>
          <p className="text-white/90 text-base leading-relaxed">
            But that is what championships do. They turn on single moments. Coppermine's moment came
            and went over the crossbar. DELCO's moment arrived with five minutes left. That was the
            difference between the two best teams at this tournament.
          </p>
          <p className="text-white/90 text-base leading-relaxed">
            It is also worth remembering that these teams drew 2-2 earlier in the fall in a regular
            season meeting at Coppermine's facility. Every meeting between them has been tight, hard,
            and decided by fine margins. This one was no different -- just the stakes were higher than
            they have ever been.
          </p>
        </div>

        <div className="bg-brand-yellow/10 border border-brand-yellow/30 rounded-xl p-6 space-y-2 text-center">
          <p className="text-brand-yellow font-black text-2xl">FC DELCO</p>
          <p className="text-white font-bold text-lg">VA Regional Champions</p>
          <p className="text-white/70 text-sm">U13 AD - MLS NEXT Cup Qualifiers - 2026</p>
          <p className="text-white/70 text-sm mt-2 leading-relaxed">
            Six games. Six wins. Zero losses. One trophy.
          </p>
        </div>

        <div className="bg-brand-surface border border-brand-border rounded-xl p-4 flex items-center justify-between gap-3">
          <div className="min-w-0">
            <p className="text-brand-muted text-xs uppercase tracking-widest font-bold mb-1">Share this article</p>
            <p className="text-white/60 text-xs truncate">funbetz.vercel.app/news/final-recap</p>
          </div>
          <a
            href="https://funbetz.vercel.app/news/final-recap"
            target="_blank"
            rel="noopener noreferrer"
            className="flex-shrink-0 bg-brand-yellow text-black text-xs font-bold px-4 py-2 rounded-lg hover:bg-brand-yellow/90 transition-colors"
          >
            Open
          </a>
        </div>

      </article>
    </div>
  );
}
