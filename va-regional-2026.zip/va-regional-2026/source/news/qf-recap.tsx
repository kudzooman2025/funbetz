"use client";

import Link from "next/link";

export default function QFRecapPage() {
  return (
    <div className="max-w-2xl mx-auto px-4 py-8 pb-24">
      <Link href="/schedule" className="inline-flex items-center gap-1.5 text-brand-muted hover:text-white text-sm mb-6 transition-colors">
        ← Back to Schedule
      </Link>

      <article className="space-y-6">
        {/* Header */}
        <div className="space-y-2">
          <div className="inline-flex items-center gap-2 bg-orange-500/10 border border-orange-500/30 rounded-full px-3 py-1">
            <span className="text-orange-400 text-xs font-bold uppercase tracking-widest">Quarterfinal Roundup</span>
          </div>
          <h1 className="text-2xl font-bold text-white leading-tight">
            Charlotte's Shield Holds, Coppermine Survives PKs, DELCO March On
          </h1>
          <p className="text-brand-muted text-sm">
            May 3, 2026 · VA Regional · U13 AD · MLS NEXT Cup Qualifiers
          </p>
        </div>

        <div className="border-t border-brand-border" />

        {/* Intro */}
        <p className="text-white/90 text-base leading-relaxed">
          Four quarterfinals, four very different stories. The tournament's most statistically dominant
          sides held serve, a PKs thriller sent one perfect-record side home, and the semifinal lineup is
          exactly as dangerous as the bracket suggested it would be.
        </p>

        {/* QF Results */}
        <div className="space-y-3">
          <h2 className="text-lg font-bold text-white border-l-2 border-orange-500 pl-3">Quarterfinal Results</h2>

          {/* QF5 */}
          <div className="bg-white/5 border border-brand-border rounded-xl p-4 space-y-2">
            <div className="flex items-center justify-between text-xs text-brand-muted">
              <span className="font-medium uppercase tracking-wide">QF5 · A vs H</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-white/50 text-sm">Springfield SYC</span>
              <span className="text-white/50 font-bold text-lg">0</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-white font-semibold text-sm">Charlotte Independence SC</span>
              <span className="text-brand-green font-bold text-lg">2</span>
            </div>
            <p className="text-white/60 text-xs pt-1 leading-relaxed">
              Charlotte made it look easy. The group stage's most defensively disciplined side shut out
              the tournament's top seeds from Group A, winning 2–0 to extend their extraordinary run to
              <span className="text-brand-green font-semibold"> zero goals conceded</span> across four games.
            </p>
          </div>

          {/* QF6 */}
          <div className="bg-white/5 border border-brand-border rounded-xl p-4 space-y-2">
            <div className="flex items-center justify-between text-xs text-brand-muted">
              <span className="font-medium uppercase tracking-wide">QF6 · D vs E</span>
              <span className="text-brand-yellow font-semibold">PKs</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-white/50 text-sm">Baltimore Armour</span>
              <span className="text-white/50 font-bold text-lg">0 <span className="text-xs font-normal">(3)</span></span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-white font-semibold text-sm">Coppermine SC</span>
              <span className="text-brand-green font-bold text-lg">0 <span className="text-xs font-normal">(4)</span></span>
            </div>
            <p className="text-white/60 text-xs pt-1 leading-relaxed">
              The game of the round. Baltimore Armour — the only other side to match Charlotte's perfect
              9-point group stage record — were sent out on penalties. A 0–0 draw through 80 minutes
              led to a tense shootout, where Coppermine edged it 4–3. The unbeatable record is gone,
              but Baltimore exit with their heads high. Coppermine's resilience all tournament is
              now impossible to ignore.
            </p>
          </div>

          {/* QF7 */}
          <div className="bg-white/5 border border-brand-border rounded-xl p-4 space-y-2">
            <div className="flex items-center justify-between text-xs text-brand-muted">
              <span className="font-medium uppercase tracking-wide">QF7 · B vs G</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-white font-semibold text-sm">Alexandria SA</span>
              <span className="text-brand-green font-bold text-lg">✓</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-white/50 text-sm">Real Futbol Academy</span>
              <span className="text-white/50 font-bold text-lg">—</span>
            </div>
            <p className="text-white/60 text-xs pt-1 leading-relaxed">
              Alexandria SA, the Group B champions who went unbeaten with a 9-point haul and 6–1 goal
              tally, advanced past Real Futbol Academy to earn a semifinal berth. Real Futbol Academy's
              remarkable run — a rankings-defying, unbeaten group stage from a side nobody saw coming —
              comes to an end. They were one of the stories of this tournament.
            </p>
          </div>

          {/* QF8 */}
          <div className="bg-white/5 border border-brand-border rounded-xl p-4 space-y-2">
            <div className="flex items-center justify-between text-xs text-brand-muted">
              <span className="font-medium uppercase tracking-wide">QF8 · C vs F</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-white font-semibold text-sm">FC DELCO</span>
              <span className="text-brand-green font-bold text-lg">2</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-white/50 text-sm">Queen City Mutiny FC</span>
              <span className="text-white/50 font-bold text-lg">0</span>
            </div>
            <p className="text-white/60 text-xs pt-1 leading-relaxed">
              FC DELCO looked every bit a championship side. After their dramatic late winner against
              The Football Academy in Day 2, they brought a different gear here — clinical, composed,
              and 2–0 without ever looking troubled. Queen City Mutiny gave everything but had no answer.
            </p>
          </div>
        </div>

        <div className="border-t border-brand-border" />

        {/* SF Preview Header */}
        <div className="space-y-2">
          <div className="inline-flex items-center gap-2 bg-orange-500/10 border border-orange-500/30 rounded-full px-3 py-1">
            <span className="text-orange-400 text-xs font-bold uppercase tracking-widest">2:45pm Today</span>
          </div>
          <h2 className="text-xl font-bold text-white">The Last Four Standing</h2>
          <p className="text-white/70 text-sm leading-relaxed">
            Four teams remain. Two semifinal games. One shot at the championship. Everything built
            over three days comes down to the next 80 minutes — and the matchups could not be
            more perfectly drawn.
          </p>
        </div>

        {/* SF1 */}
        <div className="bg-gradient-to-b from-brand-green/10 to-transparent border border-brand-green/40 rounded-2xl p-5 space-y-4">
          <div className="flex items-center justify-between">
            <span className="text-xs text-brand-green font-bold uppercase tracking-widest">Semifinal 1 · Match 19803</span>
            <span className="text-xs text-brand-muted">2:45pm</span>
          </div>
          <p className="text-white font-bold text-lg leading-tight">
            Charlotte Independence SC<br />
            <span className="text-brand-muted font-normal text-base">vs</span><br />
            Coppermine SC
          </p>

          <div className="border-t border-brand-border" />

          <p className="text-white/80 text-sm leading-relaxed">
            Let's start with the number that defines this tournament: <span className="text-brand-green font-bold">zero</span>.
            That is how many goals Charlotte Independence SC have conceded. Not in this round — in the
            entire competition. Four games. Four clean sheets. Seventeen goals scored against them
            across three groups of opponents, and not one found the net. The goalkeeper and backline
            have been borderline untouchable, and every team to face them has left shaking their heads.
          </p>
          <p className="text-white/80 text-sm leading-relaxed">
            Now comes Coppermine SC — and they are the one side in this draw built to break exactly
            that kind of record. They do not panic. They do not concede the big moments. When Baltimore
            Armour — a team that had not dropped a single point in three group games — lined up against
            them this morning and forced a 0–0 draw into penalties, Coppermine didn't blink. They stepped
            up and won the shootout 4–3. Calm. Composed. Unmoved.
          </p>
          <p className="text-white/80 text-sm leading-relaxed">
            This is the matchup of the tournament. Charlotte's defensive record is historic for this
            competition — but Coppermine just showed they can win when the game is decided by nerve,
            not just quality. If Charlotte's wall finally cracks, it will be because a side found
            a way to make them uncomfortable. Coppermine might be that side.
          </p>

          <div className="bg-white/5 rounded-xl p-3 grid grid-cols-2 gap-3 text-center">
            <div>
              <p className="text-brand-green font-bold text-xl">0</p>
              <p className="text-white/60 text-xs">Goals against Charlotte<br/>this tournament</p>
            </div>
            <div>
              <p className="text-brand-yellow font-bold text-xl">PKs</p>
              <p className="text-white/60 text-xs">How Coppermine<br/>just survived</p>
            </div>
          </div>

          <p className="text-brand-green text-xs font-semibold italic text-center">
            The question isn't whether Charlotte are beatable. It's whether anyone has found the answer yet.
          </p>
        </div>

        {/* SF2 */}
        <div className="bg-gradient-to-b from-blue-500/10 to-transparent border border-blue-500/40 rounded-2xl p-5 space-y-4">
          <div className="flex items-center justify-between">
            <span className="text-xs text-blue-400 font-bold uppercase tracking-widest">Semifinal 2 · Match 19804</span>
            <span className="text-xs text-brand-muted">2:45pm</span>
          </div>
          <p className="text-white font-bold text-lg leading-tight">
            Alexandria SA<br />
            <span className="text-brand-muted font-normal text-base">vs</span><br />
            FC DELCO
          </p>

          <div className="border-t border-brand-border" />

          <p className="text-white/80 text-sm leading-relaxed">
            If Semifinal 1 is about a wall meeting a siege, Semifinal 2 is something different —
            it's two sides who have simply refused to lose, meeting each other for the first time,
            with a place in the final on the line.
          </p>
          <p className="text-white/80 text-sm leading-relaxed">
            <span className="text-white font-semibold">Alexandria SA</span> are everything you'd want
            in a title contender: controlled, efficient, and ruthless when it matters. They went
            through their group without dropping a game, scored 6, gave up 1, and haven't looked
            panicked at any stage of this tournament. They play with a maturity and structure that
            belies their age group. Their path here has been convincing.
          </p>
          <p className="text-white/80 text-sm leading-relaxed">
            But then there's <span className="text-white font-semibold">FC DELCO</span>. And FC DELCO
            are something else entirely. Five games played. Five wins. They dismantled opponents 8–0
            before anyone noticed. They ground out a late, dramatic winner against The Football Academy
            when the pressure was at its highest. They shut out Queen City Mutiny in the quarterfinals
            without breaking a sweat. This is a side that knows how to win in every kind of game —
            the canter, the grind, and the knife-fight.
          </p>
          <p className="text-white/80 text-sm leading-relaxed">
            There is no weakness to exploit here. Both teams are unbeaten. Both have been tested.
            The team that wins this game almost certainly wins the whole thing — because whoever
            survives a battle this fierce will be carrying serious momentum into Sunday morning's final.
          </p>

          <div className="bg-white/5 rounded-xl p-3 grid grid-cols-2 gap-3 text-center">
            <div>
              <p className="text-blue-400 font-bold text-xl">6–1</p>
              <p className="text-white/60 text-xs">Alexandria's<br/>group stage record</p>
            </div>
            <div>
              <p className="text-white font-bold text-xl">5W</p>
              <p className="text-white/60 text-xs">FC DELCO — every<br/>game, every round</p>
            </div>
          </div>

          <p className="text-blue-300 text-xs font-semibold italic text-center">
            One of these sides will have their unbeaten record end today. The other will be one step away from the title.
          </p>
        </div>

        {/* Closer */}
        <div className="bg-white/5 border border-brand-border rounded-xl p-4 space-y-2 text-center">
          <p className="text-white font-bold text-sm">Sunday · 8:00am</p>
          <p className="text-brand-muted text-xs">The final. Two survivors. One trophy.</p>
        </div>

        <div className="border-t border-brand-border" />

        {/* Footer nav */}
        <div className="flex gap-3 pt-2">
          <Link
            href="/news/day2-recap"
            className="flex-1 text-center bg-white/5 border border-brand-border text-white text-sm font-semibold py-3 rounded-xl hover:bg-white/10 transition-colors"
          >
            ← Day 2 Wrap-Up
          </Link>
          <Link
            href="/schedule"
            className="flex-1 text-center bg-brand-green text-black text-sm font-bold py-3 rounded-xl hover:bg-brand-green/80 transition-colors"
          >
            View Bracket →
          </Link>
        </div>
      </article>
    </div>
  );
}
