"use client";

import Link from "next/link";

export default function FinalPreviewPage() {
  return (
    <div className="max-w-2xl mx-auto px-4 py-8 pb-24">
      <Link href="/schedule" className="inline-flex items-center gap-1.5 text-brand-muted hover:text-white text-sm mb-6 transition-colors">
        ← Back to Schedule
      </Link>

      <article className="space-y-6">
        {/* Header */}
        <div className="space-y-2">
          <div className="inline-flex items-center gap-2 bg-brand-yellow/10 border border-brand-yellow/30 rounded-full px-3 py-1">
            <span className="text-brand-yellow text-xs font-bold uppercase tracking-widest">🏆 Championship Final</span>
          </div>
          <h1 className="text-2xl font-bold text-white leading-tight">
            The Grinders vs. The Machine: A Final Nobody Could Have Scripted
          </h1>
          <p className="text-brand-muted text-sm">
            May 3, 2026 · VA Regional · U13 AD · MLS NEXT Cup Qualifiers
          </p>
        </div>

        <div className="border-t border-brand-border" />

        {/* Intro */}
        <p className="text-white/90 text-base leading-relaxed">
          Somewhere in a tournament bracket, there is a path of destruction carved by FC DELCO — six
          straight wins, goal after goal, opponent after opponent dispatched with something close to
          clinical indifference. And then there is another path, quieter, stranger, and in many ways
          more remarkable: the path of Coppermine SC, a side that has never quite dominated, never
          looked invincible, and yet has never once lost. They meet Sunday morning at 8:00am for
          the championship. And nobody is entirely sure which story ends in a trophy.
        </p>

        <div className="border-t border-brand-border" />

        {/* SF Recap */}
        <div className="space-y-3">
          <h2 className="text-lg font-bold text-white border-l-2 border-orange-500 pl-3">How They Got Here</h2>

          <div className="bg-white/5 border border-brand-border rounded-xl p-4 space-y-2">
            <p className="text-xs text-brand-muted font-semibold uppercase tracking-wide">Semifinal 1</p>
            <div className="flex items-center justify-between">
              <span className="text-white font-semibold text-sm">Coppermine SC</span>
              <span className="text-brand-green font-bold text-lg">1</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-white/50 text-sm">Charlotte Independence SC</span>
              <span className="text-white/50 font-bold text-lg">0</span>
            </div>
            <p className="text-white/60 text-xs pt-1 leading-relaxed">
              Charlotte Independence SC had not conceded a single goal in this entire tournament.
              Four games. Zero. A defensive record that was becoming legend. And then Coppermine
              SC scored. One goal. That was all it took. The wall came down, the clean sheet
              record ended, and the tournament's most dominant defensive unit went home.
              Coppermine didn't celebrate like a team that had stolen something — they celebrated
              like a team that had known all along.
            </p>
          </div>

          <div className="bg-white/5 border border-brand-border rounded-xl p-4 space-y-2">
            <div className="flex items-center justify-between text-xs text-brand-muted">
              <span className="font-semibold uppercase tracking-wide">Semifinal 2</span>
              <span className="text-brand-yellow font-semibold">PKs</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-white font-semibold text-sm">FC DELCO</span>
              <span className="text-brand-green font-bold text-lg">1 <span className="text-sm font-normal">(4)</span></span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-white/50 text-sm">Alexandria SA</span>
              <span className="text-white/50 font-bold text-lg">1 <span className="text-sm font-normal">(2)</span></span>
            </div>
            <p className="text-white/60 text-xs pt-1 leading-relaxed">
              Alexandria SA were the one team who looked capable of stopping DELCO. Unbeaten in
              the group stage, composed, structured, dangerous on the break — they gave DELCO
              exactly the knife-fight everyone predicted.
            </p>
            <p className="text-white/60 text-xs leading-relaxed">
              DELCO drew first blood and led 1–0. Then came the moment that changed everything.
              A bar-down finish — emphatically in, no debate on the shot itself — appeared to
              double their lead to 2–0. The celebration started. The referee disallowed it.
              1–0 stayed on the board. The DELCO sideline erupted in disbelief. The game that
              should have been put to bed was left wide open.
            </p>
            <p className="text-white/60 text-xs leading-relaxed">
              Alexandria seized the lifeline. They equalized to make it 1–1, and a game DELCO
              were controlling was suddenly level with time running out. It went to penalties.
              In that pressurized moment — still stinging from the disallowed goal, having just
              surrendered their lead — FC DELCO held their nerve and won the shootout 4–2.
              Whether the call was right or wrong, what DELCO did next said everything about
              this team’s mental strength. Alexandria’s unbeaten run is over. DELCO’s continues.
            </p>
          </div>
        </div>

        {/* Controversy callout */}
        <div className="bg-red-500/10 border border-red-500/30 rounded-xl p-4 space-y-2">
          <p className="text-red-400 font-bold text-xs uppercase tracking-widest">The Goal That Wasn't</p>
          <p className="text-white/80 text-sm leading-relaxed">
            FC DELCO led 1–0 and had what appeared to be a second goal — bar down, no debate
            on the shot itself — disallowed. The 2–0 lead that would have closed the game out
            was wiped off the board. Alexandria responded, equalized to make it 1–1, and the
            game that DELCO were controlling went to a penalty shootout. DELCO still won, 4–2.
            The call didn't cost them the match. But it gave Alexandria a lifeline they
            absolutely took — and it's a moment that will be talked about long after Sunday's final.
          </p>
        </div>

        <div className="border-t border-brand-border" />

        {/* The Final */}
        <div className="space-y-2">
          <div className="inline-flex items-center gap-2 bg-brand-yellow/10 border border-brand-yellow/30 rounded-full px-3 py-1">
            <span className="text-brand-yellow text-xs font-bold uppercase tracking-widest">Sunday · 8:00am · Match 19832</span>
          </div>
          <h2 className="text-xl font-bold text-white">Coppermine SC vs FC DELCO</h2>
        </div>

        {/* Coppermine profile */}
        <div className="bg-gradient-to-b from-white/8 to-transparent border border-brand-border rounded-2xl p-5 space-y-4">
          <p className="text-brand-green text-xs font-bold uppercase tracking-widest">The Survivors</p>
          <p className="text-white font-bold text-base">Coppermine SC</p>
          <p className="text-white/80 text-sm leading-relaxed">
            Let's be honest: nobody predicted this. Coppermine came out of Group E on a tiebreaker,
            tied on points with a Fox Soccer Academy side who had the better goal differential.
            They won one game in the group stage. One. The rest were draws. They scraped through.
            And then something shifted.
          </p>
          <p className="text-white/80 text-sm leading-relaxed">
            In the quarterfinals, they faced Baltimore Armour — a side that had won every single
            group game, nine points, not a single point dropped. Coppermine held them scoreless
            for 80 minutes and then beat them in a penalty shootout. In the semifinals, they walked
            into the Charlotte Independence fortress, the one place nobody had scored all tournament,
            and scored the only goal of the game.
          </p>
          <p className="text-white/80 text-sm leading-relaxed">
            This is not a team that wins with style. This is a team that wins. There is a
            difference — and in a one-game final, it might matter more than anything.
          </p>
          <div className="bg-white/5 rounded-xl p-3 grid grid-cols-3 gap-2 text-center text-xs">
            <div>
              <p className="text-white font-bold text-base">Unbeaten</p>
              <p className="text-white/50">all tournament</p>
            </div>
            <div>
              <p className="text-brand-yellow font-bold text-base">2x PKs</p>
              <p className="text-white/50">shootouts won</p>
            </div>
            <div>
              <p className="text-brand-green font-bold text-base">1</p>
              <p className="text-white/50">goal to beat Charlotte</p>
            </div>
          </div>
        </div>

        {/* DELCO profile */}
        <div className="bg-gradient-to-b from-blue-500/8 to-transparent border border-blue-500/30 rounded-2xl p-5 space-y-4">
          <p className="text-blue-400 text-xs font-bold uppercase tracking-widest">The Machine</p>
          <p className="text-white font-bold text-base">FC DELCO</p>
          <p className="text-white/80 text-sm leading-relaxed">
            Five games. Five wins. There is no other way to describe what FC DELCO have done at
            this tournament — they have simply not lost. They did not lose when they were
            dominant. They did not lose when they were tested. They did not lose when it went
            to a penalty shootout against one of the best sides in the competition.
          </p>
          <p className="text-white/80 text-sm leading-relaxed">
            They dismantled Triangle United 5–0 before anyone was paying attention. They kept
            clean sheets against every team they faced until The Football Academy made it
            uncomfortable in Day 2 — and DELCO responded with a dramatic late winner.
            In the quarterfinals, they shut out Queen City Mutiny 2–0. In the semis, they
            survived Alexandria on penalties when the easier path ran out.
          </p>
          <p className="text-white/80 text-sm leading-relaxed">
            DELCO don't just win. They find a way to win in every single kind of game —
            the blowout, the grind, the nail-biter, and the shootout.
            That is what makes them dangerous. That is what makes them the favorite.
          </p>
          <div className="bg-white/5 rounded-xl p-3 grid grid-cols-3 gap-2 text-center text-xs">
            <div>
              <p className="text-white font-bold text-base">5W–0L</p>
              <p className="text-white/50">perfect record</p>
            </div>
            <div>
              <p className="text-blue-400 font-bold text-base">10+</p>
              <p className="text-white/50">goals scored</p>
            </div>
            <div>
              <p className="text-white font-bold text-base">Won</p>
              <p className="text-white/50">every type of game</p>
            </div>
          </div>
        </div>

        {/* History */}
        <div className="bg-white/5 border border-brand-border rounded-xl p-4 space-y-2">
          <p className="text-white font-bold text-xs uppercase tracking-widest">They've Done This Before</p>
          <p className="text-white/80 text-sm leading-relaxed">
            These two sides have history. Earlier this fall in a regular season match, FC DELCO
            traveled to Coppermine's facility and the game ended 2–2. Neither side could be
            separated. Coppermine played at home, in front of their crowd, and held the
            tournament's most dominant team to a draw. DELCO left with a point but not
            the win. Sunday's final is a rematch — and this time, a draw sends it to penalties.
          </p>
          <p className="text-white/80 text-sm leading-relaxed">
            Coppermine already know they can live with DELCO's attack. They've done it once.
            DELCO already know Coppermine won't buckle under pressure. They've seen it firsthand.
            This is a final between two sides with receipts on each other — and both camps
            will arrive Sunday morning knowing exactly what they're walking into.
          </p>
        </div>

        {/* The question */}
        <div className="bg-brand-yellow/10 border border-brand-yellow/30 rounded-xl p-5 space-y-3">
          <p className="text-brand-yellow font-bold text-sm uppercase tracking-wide">The Only Question That Matters</p>
          <p className="text-white/90 text-sm leading-relaxed">
            Can Coppermine do to FC DELCO what they did to Baltimore and Charlotte — make the
            game ugly, make it uncomfortable, make it about nerve and not quality? And if it
            goes to penalties, will DELCO hold their nerve a second time?
          </p>
          <p className="text-white/90 text-sm leading-relaxed">
            Or does DELCO's quality finally become unanswerable? Does their ability to
            win in every kind of game prove too much for a Coppermine side that has never
            quite been dominant?
          </p>
          <p className="text-brand-yellow font-semibold text-sm leading-relaxed">
            One team has won everything by being better. The other has won everything by
            refusing to lose. They met once before and couldn't settle it. Sunday morning
            at 8:00am — on a neutral field, with a trophy on the line — we finally find out.
          </p>
        </div>

        <div className="border-t border-brand-border" />

        {/* Footer nav */}
        <div className="flex gap-3 pt-2">
          <Link
            href="/news/qf-recap"
            className="flex-1 text-center bg-white/5 border border-brand-border text-white text-sm font-semibold py-3 rounded-xl hover:bg-white/10 transition-colors"
          >
            ← SF Results
          </Link>
          <Link
            href="/schedule"
            className="flex-1 text-center bg-brand-yellow text-black text-sm font-bold py-3 rounded-xl hover:bg-brand-yellow/80 transition-colors"
          >
            View Bracket →
          </Link>
        </div>
      </article>
    </div>
  );
}
