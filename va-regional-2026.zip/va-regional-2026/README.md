# MLS NEXT Cup Qualifier — Virginia Regional 2026 (Export)

A self-contained archive of the Virginia Regional tournament content, exported from FunBetz so it can live on **f6ad.space** instead. Nothing here depends on FunBetz, a database, or a build step.

## What's inside

```
index.html              Self-contained snapshot (open in any browser): champion, full
                        bracket + results, group standings by national rank, 48-game schedule.
data/tournament.json    All tournament data as clean JSON: groups, teams, national rankings,
                        group winners, every group game, and knockout results. Use this as the
                        data source when you rebuild the page on f6ad.space.
logos/                  All 33 team logo images (jpg).
reference/              Original planning docs: the seeding spreadsheet (.xlsx), the
                        "MLS NEXT Cup Seeding Explained" PDF, and the bracket QR code.
source/                 The original FunBetz code, for reuse or reference:
                          bracket-config.ts   groups, schedule, rankings, scoring, helpers
                          team-logos.ts        team name -> logo path map
                          modular11.ts         results scraper (modular11.com / mlssoccer.com)
                          seed-mlsnext.ts      DB seed for the games
                          schedule-page.tsx    the schedule + results UI (with knockout results)
                          brackets-id-page.tsx the interactive bracket picker UI
                          news/*.tsx           the 5 recap articles (day 2, QF, previews, final)
```

## The tournament in brief

32 teams, U13 Academy Division, May 1–4, 2026. Eight groups of four; **only group winners advanced** to an 8-team knockout (Quarterfinals → Semifinals → Final). QF pairings were fixed by cross-group seeding.

**Champion: FC DELCO** (national #206, the top-ranked team in the field), beating Coppermine SC 1–0 in the final after winning two penalty shootouts on the way.

Group winners: A Springfield SYC · B Alexandria SA · C FC DELCO · D Baltimore Armour · E Coppermine SC · F Queen City Mutiny FC · G Real Futbol Academy · H Charlotte Independence SC.

## Porting to f6ad.space (Next.js / Supabase)

The lightest path: drop `data/tournament.json` into your app and render it in a server component, and copy `logos/` into `public/logos/` (the JSON references logo files by their `logos/<file>.jpg` path). If you want the interactive bracket or the recap articles, `source/brackets-id-page.tsx` and `source/news/*.tsx` are drop-in React starting points; they only need your own layout, the logo map, and the data. No Supabase table is required for a read-only archive, but if you want it queryable, the shape in `tournament.json` maps cleanly onto a `groups`, `teams`, and `matches` set of tables.

## Data notes / known cleanups

- `team-logos.ts` is missing a mapping for "The Players Progression Academy"; the export adds it (`logos/players-progression-academy.jpg`).
- A `cedar-stars-monmouth.jpg` logo exists in the assets but that team isn't in the final field; kept for completeness.
- Knockout results and the champion are transcribed from the FunBetz schedule page (confirmed via modular11 / mlssoccer.com). Group-stage per-game scores lived in the FunBetz database, not in these files, so they aren't included here; standings are shown by national ranking with the confirmed group winner flagged.
